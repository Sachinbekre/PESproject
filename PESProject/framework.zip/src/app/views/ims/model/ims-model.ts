export class Ims {
    locationId: string;
    woNo: string;
    locationName: string;
    startDate: string;
    endDate: string;
}
