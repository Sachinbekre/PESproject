export class Jms {
    siteId: string;
    locationName: string;
    siteType:string;
    woNo: string;
    date: string;
    description: string;
    unit:string;
    qty:string
}
