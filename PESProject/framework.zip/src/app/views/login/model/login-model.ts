export class Login {
    userName: string;
    password: string;
}

