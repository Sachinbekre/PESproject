import { Workorder } from './workorder';

describe('Workorder', () => {
  it('should create an instance', () => {
    expect(new Workorder()).toBeTruthy();
  });
});
