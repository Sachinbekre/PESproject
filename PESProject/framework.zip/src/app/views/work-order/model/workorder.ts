export class Workorder {
    SlNo: string;
    woNo: string;
    itemCode: string;
    description: string;
    uom: string;
    qty: number;
    rate: number;
    amount: number;
}
